##############################################################################
#
# A simple example of merging the Excel data by Python.
# 
# Video explanation: https://space.bilibili.com/491348703
# 

# 导入Python-Excel 工具包
import xlrd
import xlsxwriter


# 需要合并的 Excel 文件路径
source_xls = ["C:\Python\Week2\Data11.xlsx", "C:\Python\Week2\Data12.xlsx",
              "C:\Python\Week2\Data21.xlsx", "C:\Python\Week2\Data21.xlsx"]

# 合并后的 Excel 文件存放路径
target_xls = "C:\Python\Week2\Data2_Merge.xlsx"

# 读取数据
data = []
for i in source_xls:
    wb = xlrd.open_workbook(i)
    for sheet in wb.sheets():
        for rownum in range(0,sheet.nrows):
            data.append(sheet.row_values(rownum))

# 写入数据
workbook = xlsxwriter.Workbook(target_xls)
worksheet = workbook.add_worksheet()
font = workbook.add_format({"font_size":12})
for i in range(len(data)):
    for j in range(len(data[i])):
        worksheet.write(i, j, data[i][j], font)
# 关闭文件流
workbook.close()

print("Done!!!")

