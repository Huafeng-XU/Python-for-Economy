
import os

dirname = r'C:\Python\Week2'
filename = ".xlsx"

source_path = []
def search(dirname=dirname, filename=""):
    for item in os.listdir(dirname):
        item_path = os.path.join(dirname, item)
        if os.path.isdir(item_path):
            search(item_path, filename)
        elif os.path.isfile(item_path):
            if filename in item:
                global source_path
                source_path.append(item_path)
              

if __name__ == '__main__':
    search(dirname, filename)

print("################################################")  

for i in range(0,len(source_path)):
    print(source_path[i]) 
    
print("################################################")    